<template>
  <div class="bg-dark text-white">
    <div class="container pt-5">
      <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
          <p class="display-1 text-center mb-5 fw-bold">An open-source webhook API platform</p>
          <p class="display-4 text-center mb-5 fw-light">
            With webhookie you can add powerful event-driven API (aka webhook
            API) capability to your platform, product, or integration
            architecture. Webhookie integrates with any message broker to
            provide robust asynchronous message delivery to your API consumers.
          </p>
          <div class="row">
            <div class="col-4"></div>
            <div class="col-4 text-center">
              <button type="button" class="btn btn-primary mb-5 display-7 fw-bold">
                LEARN MORE
              </button>
            </div>
            <div class="col-4"></div>
          </div>
        </div>
        <div class="col-3 pe-0"></div>
      </div>
    </div>

    <div class="row gx-0">
      <div class="col-3"></div>
      <div class="col-6 text-center">
        <img
          src="../assets/images/HomePageImg1.svg"
          class="mt-5 mb-5 pb-5"
          style="max-width: 100%"
        />
      </div>
      <div class="col-2 px-0"></div>
    </div>
    <div class="bg-primary p-5 my-5 text-center spacer">
      <p class="display-2 fw-normal">Requirement for doing business in digital age</p>
      <button type="button" class="btn btn-primary rounded-2 h7 my-3 fw-bold">
        DOWNLOAD NOW
      </button>
    </div>

    <div class="container pt-5">
      <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
          <p class="TitleFont text-center mb-5 display-1 fw-bold">Real-Time Data</p>
          <p class="display-4 text-center mb-5 fw-light">
            If you are not providing your API consumers with real-time data then
            you are not giving them the edge required to compete in today's fast
            pace and connected world.
          </p>
          <p class="display-4 text-center mb-5 fw-light">
            Decentralised IT environments require access to real-time
            asynchronous data feeds to efficiently scale and provide consistency
            across the enterprise and with business partners.
          </p>
        </div>
        <div class="col-3 pe-0"></div>
      </div>
    </div>

    <div class="row gx-0">
      <div class="col-2"></div>
      <div class="col-8">
        <img
          src="../assets/images/Group 400.svg"
          class="mt-5 mb-3 pb-5"
          style="max-width: 100%"
        />
      </div>
      <div class="col-2 px-0"></div>
    </div>

    <div class="mb-5">
      <div class="row gx-0">
        <div class="col-2"></div>
        <div class="col-8 RTDBox text-center">
          <p class="py-5 px-3 display-5 fw-lighter">
            Webhookie can give your product, platform or enterprise the edge
            with the ability to provide real-time data as a webhook API.
          </p>
        </div>
        <div class="col-2"></div>
      </div>
    </div>

    <div class="bg-primary p-5 my-5 text-center spacer display-2">
      <p class="display-2 fw-normal">An open-source webhook API platform</p>
      <button type="button" class="btn btn-primary rounded-2 my-3 display-7 fw-bold">
        DOWNLOAD NOW
      </button>
    </div>

    <div class="container pt-5">
      <div class="row">
        <div class="col-1"></div>
        <div class="col-10">
          <p class="display-1 text-center mb-5 fw-bold">Key Features</p>
          <div class="row">
            <div class="col">
              <img src="../assets/icons/Group 341.svg" class="IconStyle mb-3" />
              <p class="display-3 fw-bold">An open-source webhook API platform</p>
              <p class="display-5 fw-lighter">
                Using the ASYNC API specification design your webhook APIs in
                webhookies design console. Control who can discover, subscribe
                and manage your webhook APIs.
              </p>

              <p class="mb-5 display-7 lh-lg">LEARN MORE</p>
            </div>
            <div class="col">
              <img src="../assets/icons/Group 342.svg" class="IconStyle mb-3" />
              <p class="display-3 fw-bold">Discovery</p>
              <p class="display-5 fw-lighter">
                Provide your API consumers with a catalog of real-time data
                streams using webhookies white-labeled developer portal or build
                your own developer experience using webhookies powerful API.
              </p>
              <p class="mb-4 display-7 lh-lg">LEARN MORE</p>
            </div>
            <div class="col">
              <img src="../assets/icons/Group 343.svg" class="IconStyle mb-3" />
              <p class="display-3 fw-bold">Subscription Management</p>
              <p class="display-5 fw-lighter">
                Allow your API consumers to set up and manage their own
                subscriptions. With powerful options to validate, prove and
                reject subscriptions you have full control over who gets your
                data.
              </p>
              <p class="mb-5 display-7 lh-lg">LEARN MORE</p>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <img src="../assets/icons/Group 344.svg" class="IconStyle mb-3" />
              <p class="display-3">Traffic visibility</p>
              <p class="display-5 fw-lighter">
                Allow your API consumers to see the history of data sent to
                their system with the capability to re-send data if required
                reducing operational support requests on your team.
              </p>
              <p class="display-7 fw-bold lh-lg">LEARN MORE</p>
            </div>
            <div class="col">
              <img src="../assets/icons/Group 345.svg" class="IconStyle mb-3" />
              <p class="display-3">Guaranteed delivery</p>
              <p class="display-5 fw-lighter">
                Using the power of your message brokers, a retry strategy that
                backs off and a resend capability for longer outages webhookie
                can guarantee delivery of the messages to your API consumers.
              </p>
              <p class="display-7 fw-bold lh-lg">LEARN MORE</p>
            </div>
            <div class="col">
              <img src="../assets/icons/Vector.svg" class="IconStyle mb-3" />
              <p class="display-3">Security</p>
              <p class="display-5 fw-lighter">
                With more security options than any other webhook solution out
                there, you can implement webhookie to meet the requirements of
                your security team
              </p>
              <p class="mb-5 display-7 fw-bold lh-lg">LEARN MORE</p>
            </div>
          </div>
        </div>
        <div class="col-1 pe-0"></div>
      </div>
    </div>

    <div class="bg-primary p-5 my-5 text-center spacer">
      <p class="display-2 fw-normal">Start adding elegant event-driven integration</p>
      <button type="button" class="btn btn-primary rounded-2 my-3 display-7 fw-bold">
        DOWNLOAD NOW
      </button>
    </div>
  </div>
</template>

<script setup>
// load your data, for example:
// const {data: videos} = await useFetch('http://localhost:1337/api/videos')
</script>
<style scoped>
.spacer {
  background: linear-gradient(
    90.77deg,
    #083577 26.33%,
    #0846a2 68.39%,
    #2674e7 99.68%
  );
  box-shadow: 0px -20px 248px rgba(4, 67, 189, 0.3);
}
.RTDBox {
  background: linear-gradient(
    149.48deg,
    rgba(35, 43, 55, 0.45) 9.15%,
    rgba(0, 77, 191, 0.32) 81.46%
  );
}
.RTDBox2 {
    background:
      linear-gradient(
        149.48deg,
        rgba(35, 43, 55, 0.45) 9.15%,
        rgba(0, 77, 191, 0.32) 81.46%
      )
}
.IconStyle {
  height: 27.97476577758789px;
  width: 40px;
  left: 0px;
  top: 6.140625px;
  border-radius: 0px;
}
</style>
